#ifndef __CUTIL_H__
#define __CUTIL_H__

#include <stdlib.h>
#include <cstring>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef __HOST_DEFINES_H__
// variable modifiers
#define __shared__ __attribute((section ("__shared__"))) static
#define __device__ __attribute((section ("__device__"))) static
#define __constant__ __attribute((section ("__const__"))) static

// function modifiers
#define __global__ __attribute((noinline))
#define __host__ __attribute((noinline))
#endif

// extra modifiers
#define __input__ static

#ifndef __VECTOR_TYPES_H__
// default types
typedef struct { char x; } char1;
typedef struct { unsigned char x; } uchar1;
typedef struct { char x, y; } char2;
typedef struct { unsigned char x, y; } uchar2;
typedef struct { char x, y, z; } char3;
typedef struct { unsigned char x, y, z; } uchar3;
typedef struct { char x, y, z, w; } char4;
typedef struct { unsigned char x, y, z, w; } uchar4;

typedef struct { short x; } short1;
typedef struct { unsigned short x; } ushort1;
typedef struct { short x, y; } short2;
typedef struct { unsigned short x, y; } ushort2;
typedef struct { short x, y, z; } short3;
typedef struct { unsigned short x, y, z; } ushort3;
typedef struct { short x, y, z, w; } short4;
typedef struct { unsigned short x, y, z, w; } ushort4;

typedef struct { int x; } int1;
typedef struct { unsigned int x; } uint1;
typedef struct { int x, y; } int2;
typedef struct { unsigned int x, y; } uint2;
typedef struct { int x, y, z; } int3;
typedef struct { unsigned int x, y, z; } uint3;
typedef struct { int x, y, z, w; } int4;
typedef struct { unsigned int x, y, z, w;} uint4;

typedef struct { long x; } long1;
typedef struct { unsigned long x; } ulong1;
typedef struct { long x, y; } long2;
typedef struct { unsigned long x, y; } ulong2;
typedef struct { long x, y, z; } long3;
typedef struct { unsigned long x, y, z; } ulong3;
typedef struct { long x, y, z, w; } long4;
typedef struct { unsigned long x, y, z, w; } ulong4;

typedef struct { float x; } float1;
typedef struct { float x, y; } float2;

typedef uint2 dim2;
typedef uint3 dim3;
#endif

extern void __begin_GPU(...);
extern void __end_GPU();
extern void __modify_Grid(...);
extern void __modify_Block(...);
extern void __set_Malloc(...);
extern void __clear_Malloc(...);
//extern void __assert_fail(...);

#ifndef __DEVICE_LAUNCH_PARAMETERS_H__
// GPU configuration variables
dim3 gridDim = {1,1,1};
dim3 blockIdx;
dim3 blockDim = {2,1,1};
dim3 threadIdx;
#endif

// some commonly used macros
#define __mul24(x,y) (x) * (y)
#define __umul24(x,y) (x) * (y)
#ifndef __VECTOR_FUNCTIONS_H__
extern uint4 make_uint4(unsigned int x, unsigned int y, unsigned int z, unsigned int w);
#endif

// GPU interface functions
#define cutilSafeCall(f) f

#ifndef __CUDA_RUNTIME_H__
void cudaMalloc(void** devPtr, size_t size) {
  __set_Malloc();
  *devPtr = malloc(size);
  __clear_Malloc();
}

void cudaFree(void* devPtr) {
  free(devPtr); 
}

static inline int atomicAdd(int *addr, int val) {
  int old = *addr;
  *addr = old + val;
  return old;
}

static inline int atomicSub(int *addr, int val) {
  int old = *addr;
  *addr = old - val;
  return old;
}

static inline int atomicExch(int *addr, int val) {
  int old = *addr;
  *addr = val;
  return old;
}

static inline int atomicMin(int *addr, int val) {
  int old = *addr;
  *addr = (old < val) ? old:val;
  return old;
}

static inline int atomicMax(int *addr, int val) {
  int old = *addr;
  *addr = (old > val) ? old:val;
  return old;
}

static inline int atomicOr(int *addr, int val) {
  int old = *addr;
  *addr = (old | val);
  return old;
}

static inline float2 make_float2(float x, float y) {
  float2 t;
  t.x = x;
  t.y = y;
  return t;
}
#endif

#ifndef __DRIVER_TYPES_H__
  enum HDType {cudaMemcpyHostToDevice, cudaMemcpyDeviceToHost,
	       cudaMemcpyHostToHost, cudaMemcpyDeviceToDevice};
#endif
#ifndef __CUDA_RUNTIME_API_H__
void cudaMemcpy(void* a, const void* b, size_t size, ...) {
  memcpy(a,b,size);
}

void cudaMemset(void* a, int v, size_t size) {
  memset(a, v, size);
}
#endif

// GPU functions
extern void __syncthreads();
#define _bar __syncthreads

// More library calls...
#define shrLog printf


#ifdef __cplusplus
}
#endif

#endif
