typedef char __nv_bool;
struct CUstream_st;
enum __codecvt_result {
__codecvt_ok,
__codecvt_partial,
__codecvt_error,
__codecvt_noconv};
enum _ZUt_ {
FP_NAN,
FP_INFINITE,
FP_ZERO,
FP_SUBNORMAL,
FP_NORMAL};
enum _LIB_VERSION_TYPE {
_IEEE_ = (-1),
_SVID_,
_XOPEN_,
_POSIX_,
_ISOC_};
struct CUDPPHandle;
struct RadixSort;
enum kernelName {
SORT_KERNEL_EMPTY,
SORT_KERNEL_RADIX_SORT_BLOCKS,
SORT_KERNEL_RADIX_SORT_BLOCKS_KEYSONLY,
SORT_KERNEL_FIND_RADIX_OFFSETS,
SORT_KERNEL_REORDER_DATA,
SORT_KERNEL_REORDER_DATA_KEYSONLY,
SORT_KERNEL_COUNT};
enum _ZNSt9__is_voidIvEUt_E {
_ZNSt9__is_voidIvE7__valueE = 1};
enum _ZNSt12__is_integerIbEUt_E {
_ZNSt12__is_integerIbE7__valueE = 1};
enum _ZNSt12__is_integerIcEUt_E {
_ZNSt12__is_integerIcE7__valueE = 1};
enum _ZNSt12__is_integerIaEUt_E {
_ZNSt12__is_integerIaE7__valueE = 1};
enum _ZNSt12__is_integerIhEUt_E {
_ZNSt12__is_integerIhE7__valueE = 1};
enum _ZNSt12__is_integerIwEUt_E {
_ZNSt12__is_integerIwE7__valueE = 1};
enum _ZNSt12__is_integerIsEUt_E {
_ZNSt12__is_integerIsE7__valueE = 1};
enum _ZNSt12__is_integerItEUt_E {
_ZNSt12__is_integerItE7__valueE = 1};
enum _ZNSt12__is_integerIiEUt_E {
_ZNSt12__is_integerIiE7__valueE = 1};
enum _ZNSt12__is_integerIjEUt_E {
_ZNSt12__is_integerIjE7__valueE = 1};
enum _ZNSt12__is_integerIlEUt_E {
_ZNSt12__is_integerIlE7__valueE = 1};
enum _ZNSt12__is_integerImEUt_E {
_ZNSt12__is_integerImE7__valueE = 1};
enum _ZNSt12__is_integerIxEUt_E {
_ZNSt12__is_integerIxE7__valueE = 1};
enum _ZNSt12__is_integerIyEUt_E {
_ZNSt12__is_integerIyE7__valueE = 1};
enum _ZNSt13__is_floatingIfEUt_E {
_ZNSt13__is_floatingIfE7__valueE = 1};
enum _ZNSt13__is_floatingIdEUt_E {
_ZNSt13__is_floatingIdE7__valueE = 1};
enum _ZNSt13__is_floatingIeEUt_E {
_ZNSt13__is_floatingIeE7__valueE = 1};
enum _ZNSt9__is_charIcEUt_E {
_ZNSt9__is_charIcE7__valueE = 1};
enum _ZNSt9__is_charIwEUt_E {
_ZNSt9__is_charIwE7__valueE = 1};
enum _ZNSt9__is_byteIcEUt_E {
_ZNSt9__is_byteIcE7__valueE = 1};
enum _ZNSt9__is_byteIaEUt_E {
_ZNSt9__is_byteIaE7__valueE = 1};
enum _ZNSt9__is_byteIhEUt_E {
_ZNSt9__is_byteIhE7__valueE = 1};
enum _ZStUt_ {
_ZSt12_S_threshold = 16};
enum _ZStUt0_ {
_ZSt13_S_chunk_size = 7};
typedef unsigned long size_t;




typedef __attribute__((device_builtin_texture_type)) const void *__texture_type__;
typedef __attribute__((device_builtin_surface_type)) const void *__surface_type__;
extern __attribute__((device)) __attribute__((section("__device__"))) void* malloc(size_t);
extern __attribute__((device)) __attribute__((section("__device__"))) void free(void*);

extern __attribute__((device)) __attribute__((section("__device__"))) void __assertfail(
  const void *message,
  const void *file,
  unsigned int line,
  const void *function,
  size_t charsize);
static __attribute__((device)) __attribute__((section("__device__"))) void __assert_fail(
  const char *__assertion,
  const char *__file,
  unsigned int __line,
  const char *__function)
{
  __assertfail(
    (const void *)__assertion,
    (const void *)__file,
                  __line,
    (const void *)__function,
    sizeof(char));
}







enum __attribute__((device_builtin)) cudaRoundMode
{
    cudaRoundNearest,
    cudaRoundZero,
    cudaRoundPosInf,
    cudaRoundMinInf
};
enum __attribute__((device_builtin)) cudaError
{





    cudaSuccess = 0,





    cudaErrorMissingConfiguration = 1,





    cudaErrorMemoryAllocation = 2,





    cudaErrorInitializationError = 3,
    cudaErrorLaunchFailure = 4,
    cudaErrorPriorLaunchFailure = 5,
    cudaErrorLaunchTimeout = 6,
    cudaErrorLaunchOutOfResources = 7,





    cudaErrorInvalidDeviceFunction = 8,
    cudaErrorInvalidConfiguration = 9,





    cudaErrorInvalidDevice = 10,





    cudaErrorInvalidValue = 11,





    cudaErrorInvalidPitchValue = 12,





    cudaErrorInvalidSymbol = 13,




    cudaErrorMapBufferObjectFailed = 14,




    cudaErrorUnmapBufferObjectFailed = 15,





    cudaErrorInvalidHostPointer = 16,





    cudaErrorInvalidDevicePointer = 17,





    cudaErrorInvalidTexture = 18,





    cudaErrorInvalidTextureBinding = 19,






    cudaErrorInvalidChannelDescriptor = 20,





    cudaErrorInvalidMemcpyDirection = 21,
    cudaErrorAddressOfConstant = 22,
    cudaErrorTextureFetchFailed = 23,
    cudaErrorTextureNotBound = 24,
    cudaErrorSynchronizationError = 25,





    cudaErrorInvalidFilterSetting = 26,





    cudaErrorInvalidNormSetting = 27,







    cudaErrorMixedDeviceExecution = 28,






    cudaErrorCudartUnloading = 29,




    cudaErrorUnknown = 30,







    cudaErrorNotYetImplemented = 31,
    cudaErrorMemoryValueTooLarge = 32,






    cudaErrorInvalidResourceHandle = 33,







    cudaErrorNotReady = 34,






    cudaErrorInsufficientDriver = 35,
    cudaErrorSetOnActiveProcess = 36,





    cudaErrorInvalidSurface = 37,





    cudaErrorNoDevice = 38,





    cudaErrorECCUncorrectable = 39,




    cudaErrorSharedObjectSymbolNotFound = 40,




    cudaErrorSharedObjectInitFailed = 41,





    cudaErrorUnsupportedLimit = 42,





    cudaErrorDuplicateVariableName = 43,





    cudaErrorDuplicateTextureName = 44,





    cudaErrorDuplicateSurfaceName = 45,
    cudaErrorDevicesUnavailable = 46,




    cudaErrorInvalidKernelImage = 47,







    cudaErrorNoKernelImageForDevice = 48,
    cudaErrorIncompatibleDriverContext = 49,






    cudaErrorPeerAccessAlreadyEnabled = 50,






    cudaErrorPeerAccessNotEnabled = 51,





    cudaErrorDeviceAlreadyInUse = 54,







    cudaErrorProfilerDisabled = 55,






    cudaErrorProfilerNotInitialized = 56,






    cudaErrorProfilerAlreadyStarted = 57,





     cudaErrorProfilerAlreadyStopped = 58,







    cudaErrorAssert = 59,






    cudaErrorTooManyPeers = 60,





    cudaErrorHostMemoryAlreadyRegistered = 61,





    cudaErrorHostMemoryNotRegistered = 62,




    cudaErrorOperatingSystem = 63,




    cudaErrorStartupFailure = 0x7f,







    cudaErrorApiFailureBase = 10000
};




enum __attribute__((device_builtin)) cudaChannelFormatKind
{
    cudaChannelFormatKindSigned = 0,
    cudaChannelFormatKindUnsigned = 1,
    cudaChannelFormatKindFloat = 2,
    cudaChannelFormatKindNone = 3
};




struct __attribute__((device_builtin)) cudaChannelFormatDesc
{
    int x;
    int y;
    int z;
    int w;
    enum cudaChannelFormatKind f;
};




struct cudaArray;




enum __attribute__((device_builtin)) cudaMemoryType
{
    cudaMemoryTypeHost = 1,
    cudaMemoryTypeDevice = 2
};




enum __attribute__((device_builtin)) cudaMemcpyKind
{
    cudaMemcpyHostToHost = 0,
    cudaMemcpyHostToDevice = 1,
    cudaMemcpyDeviceToHost = 2,
    cudaMemcpyDeviceToDevice = 3,
    cudaMemcpyDefault = 4
};





struct __attribute__((device_builtin)) cudaPitchedPtr
{
    void *ptr;
    size_t pitch;
    size_t xsize;
    size_t ysize;
};





struct __attribute__((device_builtin)) cudaExtent
{
    size_t width;
    size_t height;
    size_t depth;
};





struct __attribute__((device_builtin)) cudaPos
{
    size_t x;
    size_t y;
    size_t z;
};




struct __attribute__((device_builtin)) cudaMemcpy3DParms
{
    struct cudaArray *srcArray;
    struct cudaPos srcPos;
    struct cudaPitchedPtr srcPtr;

    struct cudaArray *dstArray;
    struct cudaPos dstPos;
    struct cudaPitchedPtr dstPtr;

    struct cudaExtent extent;
    enum cudaMemcpyKind kind;
};




struct __attribute__((device_builtin)) cudaMemcpy3DPeerParms
{
    struct cudaArray *srcArray;
    struct cudaPos srcPos;
    struct cudaPitchedPtr srcPtr;
    int srcDevice;

    struct cudaArray *dstArray;
    struct cudaPos dstPos;
    struct cudaPitchedPtr dstPtr;
    int dstDevice;

    struct cudaExtent extent;
};




struct cudaGraphicsResource;




enum __attribute__((device_builtin)) cudaGraphicsRegisterFlags
{
    cudaGraphicsRegisterFlagsNone = 0,
    cudaGraphicsRegisterFlagsReadOnly = 1,
    cudaGraphicsRegisterFlagsWriteDiscard = 2,
    cudaGraphicsRegisterFlagsSurfaceLoadStore = 4,
    cudaGraphicsRegisterFlagsTextureGather = 8
};




enum __attribute__((device_builtin)) cudaGraphicsMapFlags
{
    cudaGraphicsMapFlagsNone = 0,
    cudaGraphicsMapFlagsReadOnly = 1,
    cudaGraphicsMapFlagsWriteDiscard = 2
};




enum __attribute__((device_builtin)) cudaGraphicsCubeFace
{
    cudaGraphicsCubeFacePositiveX = 0x00,
    cudaGraphicsCubeFaceNegativeX = 0x01,
    cudaGraphicsCubeFacePositiveY = 0x02,
    cudaGraphicsCubeFaceNegativeY = 0x03,
    cudaGraphicsCubeFacePositiveZ = 0x04,
    cudaGraphicsCubeFaceNegativeZ = 0x05
};




struct __attribute__((device_builtin)) cudaPointerAttributes
{




    enum cudaMemoryType memoryType;
    int device;





    void *devicePointer;





    void *hostPointer;
};




struct __attribute__((device_builtin)) cudaFuncAttributes
{





   size_t sharedSizeBytes;





   size_t constSizeBytes;




   size_t localSizeBytes;






   int maxThreadsPerBlock;




   int numRegs;






   int ptxVersion;






   int binaryVersion;
};




enum __attribute__((device_builtin)) cudaFuncCache
{
    cudaFuncCachePreferNone = 0,
    cudaFuncCachePreferShared = 1,
    cudaFuncCachePreferL1 = 2,
    cudaFuncCachePreferEqual = 3
};





enum __attribute__((device_builtin)) cudaSharedMemConfig
{
    cudaSharedMemBankSizeDefault = 0,
    cudaSharedMemBankSizeFourByte = 1,
    cudaSharedMemBankSizeEightByte = 2
};




enum __attribute__((device_builtin)) cudaComputeMode
{
    cudaComputeModeDefault = 0,
    cudaComputeModeExclusive = 1,
    cudaComputeModeProhibited = 2,
    cudaComputeModeExclusiveProcess = 3
};




enum __attribute__((device_builtin)) cudaLimit
{
    cudaLimitStackSize = 0x00,
    cudaLimitPrintfFifoSize = 0x01,
    cudaLimitMallocHeapSize = 0x02
};




enum __attribute__((device_builtin)) cudaOutputMode
{
    cudaKeyValuePair = 0x00,
    cudaCSV = 0x01
};




struct __attribute__((device_builtin)) cudaDeviceProp
{
    char name[256];
    size_t totalGlobalMem;
    size_t sharedMemPerBlock;
    int regsPerBlock;
    int warpSize;
    size_t memPitch;
    int maxThreadsPerBlock;
    int maxThreadsDim[3];
    int maxGridSize[3];
    int clockRate;
    size_t totalConstMem;
    int major;
    int minor;
    size_t textureAlignment;
    size_t texturePitchAlignment;
    int deviceOverlap;
    int multiProcessorCount;
    int kernelExecTimeoutEnabled;
    int integrated;
    int canMapHostMemory;
    int computeMode;
    int maxTexture1D;
    int maxTexture1DLinear;
    int maxTexture2D[2];
    int maxTexture2DLinear[3];
    int maxTexture2DGather[2];
    int maxTexture3D[3];
    int maxTextureCubemap;
    int maxTexture1DLayered[2];
    int maxTexture2DLayered[3];
    int maxTextureCubemapLayered[2];
    int maxSurface1D;
    int maxSurface2D[2];
    int maxSurface3D[3];
    int maxSurface1DLayered[2];
    int maxSurface2DLayered[3];
    int maxSurfaceCubemap;
    int maxSurfaceCubemapLayered[2];
    size_t surfaceAlignment;
    int concurrentKernels;
    int ECCEnabled;
    int pciBusID;
    int pciDeviceID;
    int pciDomainID;
    int tccDriver;
    int asyncEngineCount;
    int unifiedAddressing;
    int memoryClockRate;
    int memoryBusWidth;
    int l2CacheSize;
    int maxThreadsPerMultiProcessor;
};
struct __attribute__((device_builtin)) cudaIpcEventHandle_st
{
    char reserved[64];
};

struct __attribute__((device_builtin)) cudaIpcMemHandle_st
{
    char reserved[64];
};
typedef __attribute__((device_builtin)) enum cudaError cudaError_t;




typedef __attribute__((device_builtin)) struct CUstream_st *cudaStream_t;




typedef __attribute__((device_builtin)) struct CUevent_st *cudaEvent_t;




typedef __attribute__((device_builtin)) struct cudaGraphicsResource *cudaGraphicsResource_t;




typedef __attribute__((device_builtin)) struct CUuuid_st cudaUUID_t;




typedef __attribute__((device_builtin)) struct cudaIpcEventHandle_st cudaIpcEventHandle_t;
typedef __attribute__((device_builtin)) struct cudaIpcMemHandle_st cudaIpcMemHandle_t;




typedef __attribute__((device_builtin)) enum cudaOutputMode cudaOutputMode_t;
enum __attribute__((device_builtin)) cudaSurfaceBoundaryMode
{
    cudaBoundaryModeZero = 0,
    cudaBoundaryModeClamp = 1,
    cudaBoundaryModeTrap = 2
};




enum __attribute__((device_builtin)) cudaSurfaceFormatMode
{
    cudaFormatModeForced = 0,
    cudaFormatModeAuto = 1
};




struct __attribute__((device_builtin)) surfaceReference
{



    struct cudaChannelFormatDesc channelDesc;
};
enum __attribute__((device_builtin)) cudaTextureAddressMode
{
    cudaAddressModeWrap = 0,
    cudaAddressModeClamp = 1,
    cudaAddressModeMirror = 2,
    cudaAddressModeBorder = 3
};




enum __attribute__((device_builtin)) cudaTextureFilterMode
{
    cudaFilterModePoint = 0,
    cudaFilterModeLinear = 1
};




enum __attribute__((device_builtin)) cudaTextureReadMode
{
    cudaReadModeElementType = 0,
    cudaReadModeNormalizedFloat = 1
};




struct __attribute__((device_builtin)) textureReference
{



    int normalized;



    enum cudaTextureFilterMode filterMode;



    enum cudaTextureAddressMode addressMode[3];



    struct cudaChannelFormatDesc channelDesc;



    int sRGB;
    int __cudaReserved[15];
};
struct __attribute__((device_builtin)) char1
{
    signed char x;
};

struct __attribute__((device_builtin)) uchar1
{
    unsigned char x;
};


struct __attribute__((device_builtin)) __attribute__((aligned(2))) char2
{
    signed char x, y;
};

struct __attribute__((device_builtin)) __attribute__((aligned(2))) uchar2
{
    unsigned char x, y;
};

struct __attribute__((device_builtin)) char3
{
    signed char x, y, z;
};

struct __attribute__((device_builtin)) uchar3
{
    unsigned char x, y, z;
};

struct __attribute__((device_builtin)) __attribute__((aligned(4))) char4
{
    signed char x, y, z, w;
};

struct __attribute__((device_builtin)) __attribute__((aligned(4))) uchar4
{
    unsigned char x, y, z, w;
};

struct __attribute__((device_builtin)) short1
{
    short x;
};

struct __attribute__((device_builtin)) ushort1
{
    unsigned short x;
};

struct __attribute__((device_builtin)) __attribute__((aligned(4))) short2
{
    short x, y;
};

struct __attribute__((device_builtin)) __attribute__((aligned(4))) ushort2
{
    unsigned short x, y;
};

struct __attribute__((device_builtin)) short3
{
    short x, y, z;
};

struct __attribute__((device_builtin)) ushort3
{
    unsigned short x, y, z;
};

struct __attribute__((device_builtin)) __attribute__((aligned(8))) short4 { short x; short y; short z; short w; };
struct __attribute__((device_builtin)) __attribute__((aligned(8))) ushort4 { unsigned short x; unsigned short y; unsigned short z; unsigned short w; };

struct __attribute__((device_builtin)) int1
{
    int x;
};

struct __attribute__((device_builtin)) uint1
{
    unsigned int x;
};

struct __attribute__((device_builtin)) __attribute__((aligned(8))) int2 { int x; int y; };
struct __attribute__((device_builtin)) __attribute__((aligned(8))) uint2 { unsigned int x; unsigned int y; };

struct __attribute__((device_builtin)) int3
{
    int x, y, z;
};

struct __attribute__((device_builtin)) uint3
{
    unsigned int x, y, z;
};

struct __attribute__((device_builtin)) __attribute__((aligned(16))) int4
{
    int x, y, z, w;
};

struct __attribute__((device_builtin)) __attribute__((aligned(16))) uint4
{
    unsigned int x, y, z, w;
};

struct __attribute__((device_builtin)) long1
{
    long int x;
};

struct __attribute__((device_builtin)) ulong1
{
    unsigned long x;
};






struct __attribute__((device_builtin)) __attribute__((aligned(2*sizeof(long int)))) long2
{
    long int x, y;
};

struct __attribute__((device_builtin)) __attribute__((aligned(2*sizeof(unsigned long int)))) ulong2
{
    unsigned long int x, y;
};



struct __attribute__((device_builtin)) long3
{
    long int x, y, z;
};

struct __attribute__((device_builtin)) ulong3
{
    unsigned long int x, y, z;
};

struct __attribute__((device_builtin)) __attribute__((aligned(16))) long4
{
    long int x, y, z, w;
};

struct __attribute__((device_builtin)) __attribute__((aligned(16))) ulong4
{
    unsigned long int x, y, z, w;
};

struct __attribute__((device_builtin)) float1
{
    float x;
};

struct __attribute__((device_builtin)) __attribute__((aligned(8))) float2 { float x; float y; };

struct __attribute__((device_builtin)) float3
{
    float x, y, z;
};

struct __attribute__((device_builtin)) __attribute__((aligned(16))) float4
{
    float x, y, z, w;
};

struct __attribute__((device_builtin)) longlong1
{
    long long int x;
};

struct __attribute__((device_builtin)) ulonglong1
{
    unsigned long long int x;
};

struct __attribute__((device_builtin)) __attribute__((aligned(16))) longlong2
{
    long long int x, y;
};

struct __attribute__((device_builtin)) __attribute__((aligned(16))) ulonglong2
{
    unsigned long long int x, y;
};

struct __attribute__((device_builtin)) longlong3
{
    long long int x, y, z;
};

struct __attribute__((device_builtin)) ulonglong3
{
    unsigned long long int x, y, z;
};

struct __attribute__((device_builtin)) __attribute__((aligned(16))) longlong4
{
    long long int x, y, z ,w;
};

struct __attribute__((device_builtin)) __attribute__((aligned(16))) ulonglong4
{
    unsigned long long int x, y, z, w;
};

struct __attribute__((device_builtin)) double1
{
    double x;
};

struct __attribute__((device_builtin)) __attribute__((aligned(16))) double2
{
    double x, y;
};

struct __attribute__((device_builtin)) double3
{
    double x, y, z;
};

struct __attribute__((device_builtin)) __attribute__((aligned(16))) double4
{
    double x, y, z, w;
};
typedef __attribute__((device_builtin)) struct char1 char1;
typedef __attribute__((device_builtin)) struct uchar1 uchar1;
typedef __attribute__((device_builtin)) struct char2 char2;
typedef __attribute__((device_builtin)) struct uchar2 uchar2;
typedef __attribute__((device_builtin)) struct char3 char3;
typedef __attribute__((device_builtin)) struct uchar3 uchar3;
typedef __attribute__((device_builtin)) struct char4 char4;
typedef __attribute__((device_builtin)) struct uchar4 uchar4;
typedef __attribute__((device_builtin)) struct short1 short1;
typedef __attribute__((device_builtin)) struct ushort1 ushort1;
typedef __attribute__((device_builtin)) struct short2 short2;
typedef __attribute__((device_builtin)) struct ushort2 ushort2;
typedef __attribute__((device_builtin)) struct short3 short3;
typedef __attribute__((device_builtin)) struct ushort3 ushort3;
typedef __attribute__((device_builtin)) struct short4 short4;
typedef __attribute__((device_builtin)) struct ushort4 ushort4;
typedef __attribute__((device_builtin)) struct int1 int1;
typedef __attribute__((device_builtin)) struct uint1 uint1;
typedef __attribute__((device_builtin)) struct int2 int2;
typedef __attribute__((device_builtin)) struct uint2 uint2;
typedef __attribute__((device_builtin)) struct int3 int3;
typedef __attribute__((device_builtin)) struct uint3 uint3;
typedef __attribute__((device_builtin)) struct int4 int4;
typedef __attribute__((device_builtin)) struct uint4 uint4;
typedef __attribute__((device_builtin)) struct long1 long1;
typedef __attribute__((device_builtin)) struct ulong1 ulong1;
typedef __attribute__((device_builtin)) struct long2 long2;
typedef __attribute__((device_builtin)) struct ulong2 ulong2;
typedef __attribute__((device_builtin)) struct long3 long3;
typedef __attribute__((device_builtin)) struct ulong3 ulong3;
typedef __attribute__((device_builtin)) struct long4 long4;
typedef __attribute__((device_builtin)) struct ulong4 ulong4;
typedef __attribute__((device_builtin)) struct float1 float1;
typedef __attribute__((device_builtin)) struct float2 float2;
typedef __attribute__((device_builtin)) struct float3 float3;
typedef __attribute__((device_builtin)) struct float4 float4;
typedef __attribute__((device_builtin)) struct longlong1 longlong1;
typedef __attribute__((device_builtin)) struct ulonglong1 ulonglong1;
typedef __attribute__((device_builtin)) struct longlong2 longlong2;
typedef __attribute__((device_builtin)) struct ulonglong2 ulonglong2;
typedef __attribute__((device_builtin)) struct longlong3 longlong3;
typedef __attribute__((device_builtin)) struct ulonglong3 ulonglong3;
typedef __attribute__((device_builtin)) struct longlong4 longlong4;
typedef __attribute__((device_builtin)) struct ulonglong4 ulonglong4;
typedef __attribute__((device_builtin)) struct double1 double1;
typedef __attribute__((device_builtin)) struct double2 double2;
typedef __attribute__((device_builtin)) struct double3 double3;
typedef __attribute__((device_builtin)) struct double4 double4;







struct __attribute__((device_builtin)) dim3
{
    unsigned int x, y, z;





};

typedef __attribute__((device_builtin)) struct dim3 dim3;
uint3 __attribute__((device_builtin)) extern const threadIdx;
uint3 __attribute__((device_builtin)) extern const blockIdx;
dim3 __attribute__((device_builtin)) extern const blockDim;
dim3 __attribute__((device_builtin)) extern const gridDim;
int __attribute__((device_builtin)) extern const warpSize;
typedef unsigned uint;
struct CUDPPHandle {char __nv_no_debug_dummy_end_padding_0;};
struct RadixSort {
struct CUDPPHandle mScanPlan;
unsigned mNumElements;
unsigned *mTempKeys;
unsigned *mTempValues;
unsigned *mCounters;
unsigned *mCountersSum;
unsigned *mBlockOffsets;};
 __attribute__((device_builtin)) extern __attribute__((device)) __attribute__((section("__device__"))) int printf(const char *__restrict__, ...);
 __attribute__((device_builtin)) extern __attribute__((device)) __attribute__((section("__device__"))) void __syncthreads(void);
 __attribute__((device_builtin)) extern __attribute__((device)) __attribute__((section("__device__"))) unsigned __umul24(unsigned, unsigned);
extern __attribute__((device)) __attribute__((section("__device__"))) uint _Z9floatFlipILb1EEjj(uint);
extern __attribute__((device)) __attribute__((section("__device__"))) uint _Z11floatUnflipILb1EEjj(uint);
extern __attribute__((device)) __attribute__((section("__device__"))) uint4 _Z5scan45uint4(uint4);
extern __attribute__((device)) __attribute__((section("__device__"))) uint _Z8scanwarpIjLi4EET_S0_PS0_(uint, uint *);
extern __attribute__((device)) __attribute__((section("__device__"))) uint _Z8scanwarpIjLi2EET_S0_PS0_(uint, uint *);
extern __attribute__((device)) __attribute__((section("__device__"))) void _Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4(uint4 *);
extern __attribute__((device)) __attribute__((section("__device__"))) uint4 _Z5rank4ILi256EE5uint4S0_(uint4);
extern __attribute__((device)) __attribute__((section("__device__"))) uint _Z9floatFlipILb0EEjj(uint);
__attribute__((global)) extern void _Z10flipFloatsPjj(uint *, uint);
__attribute__((global)) extern void _Z12unflipFloatsPjj(uint *, uint);
__attribute__((global)) extern void _Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb1ELb1EEvP5uint4S1_jj(uint4 *, uint4 *, uint, uint);
__attribute__((global)) extern void _Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb1ELb0EEvP5uint4S1_jj(uint4 *, uint4 *, uint, uint);
__attribute__((global)) extern void _Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb1ELb1EEvP5uint4S1_jj(uint4 *, uint4 *, uint, uint);
__attribute__((global)) extern void _Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb1ELb0EEvP5uint4S1_jj(uint4 *, uint4 *, uint, uint);
__attribute__((global)) extern void _Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb0ELb1EEvP5uint4S1_jj(uint4 *, uint4 *, uint, uint);
__attribute__((global)) extern void _Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb0ELb0EEvP5uint4S1_jj(uint4 *, uint4 *, uint, uint);
__attribute__((global)) extern void _Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb0ELb1EEvP5uint4S1_jj(uint4 *, uint4 *, uint, uint);
__attribute__((global)) extern void _Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb0ELb0EEvP5uint4S1_jj(uint4 *, uint4 *, uint, uint);
 __attribute__((device)) __attribute__((section("__device__"))) uint _Z9floatFlipILb1EEjj(
uint f){
{
if (1)
{
 uint __cuda_local_var_23427_14_non_const_mask;
__cuda_local_var_23427_14_non_const_mask = (((unsigned)(-((int)(f >> 31)))) | 2147483648U);
return f ^ __cuda_local_var_23427_14_non_const_mask;
} else {
return f; }
}}
 __attribute__((device)) __attribute__((section("__device__"))) uint _Z11floatUnflipILb1EEjj(
uint f){
{
if (1)
{
 uint __cuda_local_var_23445_14_non_const_mask;
__cuda_local_var_23445_14_non_const_mask = (((f >> 31) - 1U) | 2147483648U);
return f ^ __cuda_local_var_23445_14_non_const_mask;
} else {
return f; }
}}
 __attribute__((device)) __attribute__((section("__device__"))) uint4 _Z5scan45uint4(
uint4 idata){
{
 __attribute__((shared)) __attribute__((section("__shared__"))) static uint __cuda_local_var_23520_34_non_const_ptr[1024];
 uint __cuda_local_var_23522_10_non_const_idx;
 uint4 __cuda_local_var_23524_11_non_const_val4;
 uint __cuda_local_var_23525_10_non_const_sum[3];
 uint __cuda_local_var_23530_10_non_const_val;
__cuda_local_var_23522_10_non_const_idx = (threadIdx.x);
__cuda_local_var_23524_11_non_const_val4 = idata;
((__cuda_local_var_23525_10_non_const_sum)[0]) = (__cuda_local_var_23524_11_non_const_val4.x);
((__cuda_local_var_23525_10_non_const_sum)[1]) = ((__cuda_local_var_23524_11_non_const_val4.y) + ((__cuda_local_var_23525_10_non_const_sum)[0]));
((__cuda_local_var_23525_10_non_const_sum)[2]) = ((__cuda_local_var_23524_11_non_const_val4.z) + ((__cuda_local_var_23525_10_non_const_sum)[1]));
__cuda_local_var_23530_10_non_const_val = ((__cuda_local_var_23524_11_non_const_val4.w) + ((__cuda_local_var_23525_10_non_const_sum)[2]));
__cuda_local_var_23530_10_non_const_val = (_Z8scanwarpIjLi4EET_S0_PS0_(__cuda_local_var_23530_10_non_const_val, (__cuda_local_var_23520_34_non_const_ptr)));
__syncthreads();
if ((__cuda_local_var_23522_10_non_const_idx & 31U) == 31U)
{
((__cuda_local_var_23520_34_non_const_ptr)[(__cuda_local_var_23522_10_non_const_idx >> 5)]) = ((__cuda_local_var_23530_10_non_const_val + (__cuda_local_var_23524_11_non_const_val4.w)) + ((__cuda_local_var_23525_10_non_const_sum)[2]));
}
__syncthreads();
{
((__cuda_local_var_23520_34_non_const_ptr)[__cuda_local_var_23522_10_non_const_idx]) = (_Z8scanwarpIjLi2EET_S0_PS0_(((__cuda_local_var_23520_34_non_const_ptr)[__cuda_local_var_23522_10_non_const_idx]), (__cuda_local_var_23520_34_non_const_ptr)));
}
__syncthreads();
__cuda_local_var_23530_10_non_const_val += ((__cuda_local_var_23520_34_non_const_ptr)[(__cuda_local_var_23522_10_non_const_idx >> 5)]);
(__cuda_local_var_23524_11_non_const_val4.x) = __cuda_local_var_23530_10_non_const_val;
(__cuda_local_var_23524_11_non_const_val4.y) = (__cuda_local_var_23530_10_non_const_val + ((__cuda_local_var_23525_10_non_const_sum)[0]));
(__cuda_local_var_23524_11_non_const_val4.z) = (__cuda_local_var_23530_10_non_const_val + ((__cuda_local_var_23525_10_non_const_sum)[1]));
(__cuda_local_var_23524_11_non_const_val4.w) = (__cuda_local_var_23530_10_non_const_val + ((__cuda_local_var_23525_10_non_const_sum)[2]));
return __cuda_local_var_23524_11_non_const_val4;
}}
 __attribute__((device)) __attribute__((section("__device__"))) uint _Z8scanwarpIjLi4EET_S0_PS0_(
uint val,
uint *sData){
{
 int __cuda_local_var_23493_9_non_const_idx;
 uint __cuda_local_var_23499_11_non_const_t;
__cuda_local_var_23493_9_non_const_idx = ((int)((2U * (threadIdx.x)) - ((threadIdx.x) & 31U)));
(sData[__cuda_local_var_23493_9_non_const_idx]) = 0U;
__cuda_local_var_23493_9_non_const_idx += 32U;
(sData[__cuda_local_var_23493_9_non_const_idx]) = val;
__syncthreads();
__cuda_local_var_23499_11_non_const_t = (sData[(__cuda_local_var_23493_9_non_const_idx - 1)]);
__syncthreads();
(sData[__cuda_local_var_23493_9_non_const_idx]) += __cuda_local_var_23499_11_non_const_t;
__syncthreads();
__cuda_local_var_23499_11_non_const_t = (sData[(__cuda_local_var_23493_9_non_const_idx - 2)]);
__syncthreads();
(sData[__cuda_local_var_23493_9_non_const_idx]) += __cuda_local_var_23499_11_non_const_t;
__syncthreads();
__cuda_local_var_23499_11_non_const_t = (sData[(__cuda_local_var_23493_9_non_const_idx - 4)]);
__syncthreads();
(sData[__cuda_local_var_23493_9_non_const_idx]) += __cuda_local_var_23499_11_non_const_t;
__syncthreads();
__cuda_local_var_23499_11_non_const_t = (sData[(__cuda_local_var_23493_9_non_const_idx - 8)]);
__syncthreads();
(sData[__cuda_local_var_23493_9_non_const_idx]) += __cuda_local_var_23499_11_non_const_t;
__syncthreads();
__cuda_local_var_23499_11_non_const_t = (sData[(__cuda_local_var_23493_9_non_const_idx - 16)]);
__syncthreads();
(sData[__cuda_local_var_23493_9_non_const_idx]) += __cuda_local_var_23499_11_non_const_t;
__syncthreads();
return (sData[__cuda_local_var_23493_9_non_const_idx]) - val;
}}
 __attribute__((device)) __attribute__((section("__device__"))) uint _Z8scanwarpIjLi2EET_S0_PS0_(
uint val,
uint *sData){
{
 int __cuda_local_var_23493_9_non_const_idx;
 uint __cuda_local_var_23499_11_non_const_t;
__cuda_local_var_23493_9_non_const_idx = ((int)((2U * (threadIdx.x)) - ((threadIdx.x) & 31U)));
(sData[__cuda_local_var_23493_9_non_const_idx]) = 0U;
__cuda_local_var_23493_9_non_const_idx += 32U;
(sData[__cuda_local_var_23493_9_non_const_idx]) = val;
__syncthreads();
__cuda_local_var_23499_11_non_const_t = (sData[(__cuda_local_var_23493_9_non_const_idx - 1)]);
__syncthreads();
(sData[__cuda_local_var_23493_9_non_const_idx]) += __cuda_local_var_23499_11_non_const_t;
__syncthreads();
__cuda_local_var_23499_11_non_const_t = (sData[(__cuda_local_var_23493_9_non_const_idx - 2)]);
__syncthreads();
(sData[__cuda_local_var_23493_9_non_const_idx]) += __cuda_local_var_23499_11_non_const_t;
__syncthreads();
__cuda_local_var_23499_11_non_const_t = (sData[(__cuda_local_var_23493_9_non_const_idx - 4)]);
__syncthreads();
(sData[__cuda_local_var_23493_9_non_const_idx]) += __cuda_local_var_23499_11_non_const_t;
__syncthreads();
__cuda_local_var_23499_11_non_const_t = (sData[(__cuda_local_var_23493_9_non_const_idx - 8)]);
__syncthreads();
(sData[__cuda_local_var_23493_9_non_const_idx]) += __cuda_local_var_23499_11_non_const_t;
__syncthreads();
__cuda_local_var_23499_11_non_const_t = (sData[(__cuda_local_var_23493_9_non_const_idx - 16)]);
__syncthreads();
(sData[__cuda_local_var_23493_9_non_const_idx]) += __cuda_local_var_23499_11_non_const_t;
__syncthreads();
return (sData[__cuda_local_var_23493_9_non_const_idx]) - val;
}}
 __attribute__((device)) __attribute__((section("__device__"))) void _Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4(
uint4 *key){
{
 __attribute__((shared)) __attribute__((section("__shared__"))) static uint __cuda_local_var_23682_34_non_const_sMem1[4096];
{
 uint shift;
shift = 0U;
for (; (shift < 4U); ++shift)
{
 uint4 __cuda_local_var_23687_15_non_const_lsb;
 uint4 __cuda_local_var_23693_15_non_const_r;
(__cuda_local_var_23687_15_non_const_lsb.x) = ((unsigned)(!(((key->x) >> shift) & 1U)));
(__cuda_local_var_23687_15_non_const_lsb.y) = ((unsigned)(!(((key->y) >> shift) & 1U)));
(__cuda_local_var_23687_15_non_const_lsb.z) = ((unsigned)(!(((key->z) >> shift) & 1U)));
(__cuda_local_var_23687_15_non_const_lsb.w) = ((unsigned)(!(((key->w) >> shift) & 1U)));
__cuda_local_var_23693_15_non_const_r = (_Z5rank4ILi256EE5uint4S0_(__cuda_local_var_23687_15_non_const_lsb));
((__cuda_local_var_23682_34_non_const_sMem1)[((((__cuda_local_var_23693_15_non_const_r.x) & 3U) * 256U) + ((__cuda_local_var_23693_15_non_const_r.x) >> 2))]) = (key->x);
((__cuda_local_var_23682_34_non_const_sMem1)[((((__cuda_local_var_23693_15_non_const_r.y) & 3U) * 256U) + ((__cuda_local_var_23693_15_non_const_r.y) >> 2))]) = (key->y);
((__cuda_local_var_23682_34_non_const_sMem1)[((((__cuda_local_var_23693_15_non_const_r.z) & 3U) * 256U) + ((__cuda_local_var_23693_15_non_const_r.z) >> 2))]) = (key->z);
((__cuda_local_var_23682_34_non_const_sMem1)[((((__cuda_local_var_23693_15_non_const_r.w) & 3U) * 256U) + ((__cuda_local_var_23693_15_non_const_r.w) >> 2))]) = (key->w);
__syncthreads();
(key->x) = ((__cuda_local_var_23682_34_non_const_sMem1)[(threadIdx.x)]);
(key->y) = ((__cuda_local_var_23682_34_non_const_sMem1)[((threadIdx.x) + 256U)]);
(key->z) = ((__cuda_local_var_23682_34_non_const_sMem1)[((threadIdx.x) + 512U)]);
(key->w) = ((__cuda_local_var_23682_34_non_const_sMem1)[((threadIdx.x) + 768U)]);
__syncthreads();
} }
}}
 __attribute__((device)) __attribute__((section("__device__"))) uint4 _Z5rank4ILi256EE5uint4S0_(
uint4 preds){
{
 uint4 __cuda_local_var_23562_11_non_const_address;
 __attribute__((shared)) __attribute__((section("__shared__"))) static uint __cuda_local_var_23564_34_non_const_numtrue;
 uint4 __cuda_local_var_23571_11_non_const_rank;
 uint __cuda_local_var_23572_10_non_const_idx;
__cuda_local_var_23562_11_non_const_address = (_Z5scan45uint4(preds));
if ((threadIdx.x) == 255U)
{
__cuda_local_var_23564_34_non_const_numtrue = ((__cuda_local_var_23562_11_non_const_address.w) + (preds.w));
}
__syncthreads();
__cuda_local_var_23572_10_non_const_idx = ((threadIdx.x) << 2);
(__cuda_local_var_23571_11_non_const_rank.x) = ((preds.x) ? (__cuda_local_var_23562_11_non_const_address.x) : ((__cuda_local_var_23564_34_non_const_numtrue + __cuda_local_var_23572_10_non_const_idx) - (__cuda_local_var_23562_11_non_const_address.x)));
(__cuda_local_var_23571_11_non_const_rank.y) = ((preds.y) ? (__cuda_local_var_23562_11_non_const_address.y) : (((__cuda_local_var_23564_34_non_const_numtrue + __cuda_local_var_23572_10_non_const_idx) + 1U) - (__cuda_local_var_23562_11_non_const_address.y)));
(__cuda_local_var_23571_11_non_const_rank.z) = ((preds.z) ? (__cuda_local_var_23562_11_non_const_address.z) : (((__cuda_local_var_23564_34_non_const_numtrue + __cuda_local_var_23572_10_non_const_idx) + 2U) - (__cuda_local_var_23562_11_non_const_address.z)));
(__cuda_local_var_23571_11_non_const_rank.w) = ((preds.w) ? (__cuda_local_var_23562_11_non_const_address.w) : (((__cuda_local_var_23564_34_non_const_numtrue + __cuda_local_var_23572_10_non_const_idx) + 3U) - (__cuda_local_var_23562_11_non_const_address.w)));
return __cuda_local_var_23571_11_non_const_rank;
}}
 __attribute__((device)) __attribute__((section("__device__"))) uint _Z9floatFlipILb0EEjj(
uint f){
{
if (0)
{
 uint __cuda_local_var_23427_14_non_const_mask;
__cuda_local_var_23427_14_non_const_mask = (((unsigned)(-((int)(f >> 31)))) | 2147483648U);
return f ^ __cuda_local_var_23427_14_non_const_mask;
} else {
return f; }
}}
__attribute__((global)) void _Z10flipFloatsPjj(
uint *values,
uint numValues){
{
 uint __cuda_local_var_23458_10_non_const_index;
__cuda_local_var_23458_10_non_const_index = ((__umul24(((blockDim.x) * 4U), (blockIdx.x))) + (threadIdx.x));
if (__cuda_local_var_23458_10_non_const_index < numValues) {
(values[__cuda_local_var_23458_10_non_const_index]) = (_Z9floatFlipILb1EEjj((values[__cuda_local_var_23458_10_non_const_index]))); }
__cuda_local_var_23458_10_non_const_index += (blockDim.x);
if (__cuda_local_var_23458_10_non_const_index < numValues) {
(values[__cuda_local_var_23458_10_non_const_index]) = (_Z9floatFlipILb1EEjj((values[__cuda_local_var_23458_10_non_const_index]))); }
__cuda_local_var_23458_10_non_const_index += (blockDim.x);
if (__cuda_local_var_23458_10_non_const_index < numValues) {
(values[__cuda_local_var_23458_10_non_const_index]) = (_Z9floatFlipILb1EEjj((values[__cuda_local_var_23458_10_non_const_index]))); }
__cuda_local_var_23458_10_non_const_index += (blockDim.x);
if (__cuda_local_var_23458_10_non_const_index < numValues) {
(values[__cuda_local_var_23458_10_non_const_index]) = (_Z9floatFlipILb1EEjj((values[__cuda_local_var_23458_10_non_const_index]))); }
}}
__attribute__((global)) void _Z12unflipFloatsPjj(
uint *values,
uint numValues){
{
 uint __cuda_local_var_23474_10_non_const_index;
__cuda_local_var_23474_10_non_const_index = ((__umul24(((blockDim.x) * 4U), (blockIdx.x))) + (threadIdx.x));
if (__cuda_local_var_23474_10_non_const_index < numValues) {
(values[__cuda_local_var_23474_10_non_const_index]) = (_Z11floatUnflipILb1EEjj((values[__cuda_local_var_23474_10_non_const_index]))); }
__cuda_local_var_23474_10_non_const_index += (blockDim.x);
if (__cuda_local_var_23474_10_non_const_index < numValues) {
(values[__cuda_local_var_23474_10_non_const_index]) = (_Z11floatUnflipILb1EEjj((values[__cuda_local_var_23474_10_non_const_index]))); }
__cuda_local_var_23474_10_non_const_index += (blockDim.x);
if (__cuda_local_var_23474_10_non_const_index < numValues) {
(values[__cuda_local_var_23474_10_non_const_index]) = (_Z11floatUnflipILb1EEjj((values[__cuda_local_var_23474_10_non_const_index]))); }
__cuda_local_var_23474_10_non_const_index += (blockDim.x);
if (__cuda_local_var_23474_10_non_const_index < numValues) {
(values[__cuda_local_var_23474_10_non_const_index]) = (_Z11floatUnflipILb1EEjj((values[__cuda_local_var_23474_10_non_const_index]))); }
}}
__attribute__((global)) void _Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb1ELb1EEvP5uint4S1_jj(
uint4 *keysOut,
uint4 *keysIn,
uint numElements,
uint totalBlocks){
{
 uint4 __cuda_local_var_23728_11_non_const_key;
 uint __cuda_local_var_23730_10_non_const_blockId;
__cuda_local_var_23730_10_non_const_blockId = (blockIdx.x);
while ((0) || (__cuda_local_var_23730_10_non_const_blockId < totalBlocks))
{ uint4 __T216;
 uint __cuda_local_var_23734_14_non_const_i;
 uint __cuda_local_var_23735_14_non_const_idx;
__cuda_local_var_23734_14_non_const_i = ((__cuda_local_var_23730_10_non_const_blockId * (blockDim.x)) + (threadIdx.x));
__cuda_local_var_23735_14_non_const_idx = (__cuda_local_var_23734_14_non_const_i << 2);
if (0)
{
if (__cuda_local_var_23735_14_non_const_idx >= numElements)
{
__cuda_local_var_23728_11_non_const_key = ((((((__T216.x) = 4294967295U) , (void)((__T216.y) = 4294967295U)) , (void)((__T216.z) = 4294967295U)) , (void)((__T216.w) = 4294967295U)) , __T216);
}
else
{
 uint *__cuda_local_var_23747_23_non_const_keys1;
__cuda_local_var_23747_23_non_const_keys1 = ((uint *)keysIn);
(__cuda_local_var_23728_11_non_const_key.x) = ((__cuda_local_var_23735_14_non_const_idx < numElements) ? (_Z9floatFlipILb1EEjj((__cuda_local_var_23747_23_non_const_keys1[__cuda_local_var_23735_14_non_const_idx]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.y) = (((__cuda_local_var_23735_14_non_const_idx + 1U) < numElements) ? (_Z9floatFlipILb1EEjj((__cuda_local_var_23747_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 1U)]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.z) = (((__cuda_local_var_23735_14_non_const_idx + 2U) < numElements) ? (_Z9floatFlipILb1EEjj((__cuda_local_var_23747_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 2U)]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.w) = 4294967295U;
}
}
else
{
__cuda_local_var_23728_11_non_const_key = (keysIn[__cuda_local_var_23734_14_non_const_i]);
if (1)
{
(__cuda_local_var_23728_11_non_const_key.x) = (_Z9floatFlipILb1EEjj((__cuda_local_var_23728_11_non_const_key.x)));
(__cuda_local_var_23728_11_non_const_key.y) = (_Z9floatFlipILb1EEjj((__cuda_local_var_23728_11_non_const_key.y)));
(__cuda_local_var_23728_11_non_const_key.z) = (_Z9floatFlipILb1EEjj((__cuda_local_var_23728_11_non_const_key.z)));
(__cuda_local_var_23728_11_non_const_key.w) = (_Z9floatFlipILb1EEjj((__cuda_local_var_23728_11_non_const_key.w)));
}
}
__syncthreads();
_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4((&__cuda_local_var_23728_11_non_const_key));
if (0)
{
if (__cuda_local_var_23735_14_non_const_idx < numElements)
{
 uint *__cuda_local_var_23776_23_non_const_keys1;
__cuda_local_var_23776_23_non_const_keys1 = ((uint *)keysOut);
(__cuda_local_var_23776_23_non_const_keys1[__cuda_local_var_23735_14_non_const_idx]) = (__cuda_local_var_23728_11_non_const_key.x);
if ((__cuda_local_var_23735_14_non_const_idx + 1U) < numElements)
{
(__cuda_local_var_23776_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 1U)]) = (__cuda_local_var_23728_11_non_const_key.y);
if ((__cuda_local_var_23735_14_non_const_idx + 2U) < numElements)
{
(__cuda_local_var_23776_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 2U)]) = (__cuda_local_var_23728_11_non_const_key.z);
}
}
}
}
else
{
(keysOut[__cuda_local_var_23734_14_non_const_i]) = __cuda_local_var_23728_11_non_const_key;
}
if (1) {
__cuda_local_var_23730_10_non_const_blockId += (gridDim.x); } else {
goto __T217; }
} __T217:;
}}
__attribute__((global)) void _Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb1ELb0EEvP5uint4S1_jj(
uint4 *keysOut,
uint4 *keysIn,
uint numElements,
uint totalBlocks){
{
 uint4 __cuda_local_var_23728_11_non_const_key;
 uint __cuda_local_var_23730_10_non_const_blockId;
__cuda_local_var_23730_10_non_const_blockId = (blockIdx.x);
while (1)
{ uint4 __T218;
 uint __cuda_local_var_23734_14_non_const_i;
 uint __cuda_local_var_23735_14_non_const_idx;
__cuda_local_var_23734_14_non_const_i = ((__cuda_local_var_23730_10_non_const_blockId * (blockDim.x)) + (threadIdx.x));
__cuda_local_var_23735_14_non_const_idx = (__cuda_local_var_23734_14_non_const_i << 2);
if (0)
{
if (__cuda_local_var_23735_14_non_const_idx >= numElements)
{
__cuda_local_var_23728_11_non_const_key = ((((((__T218.x) = 4294967295U) , (void)((__T218.y) = 4294967295U)) , (void)((__T218.z) = 4294967295U)) , (void)((__T218.w) = 4294967295U)) , __T218);
}
else
{
 uint *__cuda_local_var_23747_23_non_const_keys1;
__cuda_local_var_23747_23_non_const_keys1 = ((uint *)keysIn);
(__cuda_local_var_23728_11_non_const_key.x) = ((__cuda_local_var_23735_14_non_const_idx < numElements) ? (_Z9floatFlipILb1EEjj((__cuda_local_var_23747_23_non_const_keys1[__cuda_local_var_23735_14_non_const_idx]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.y) = (((__cuda_local_var_23735_14_non_const_idx + 1U) < numElements) ? (_Z9floatFlipILb1EEjj((__cuda_local_var_23747_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 1U)]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.z) = (((__cuda_local_var_23735_14_non_const_idx + 2U) < numElements) ? (_Z9floatFlipILb1EEjj((__cuda_local_var_23747_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 2U)]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.w) = 4294967295U;
}
}
else
{
__cuda_local_var_23728_11_non_const_key = (keysIn[__cuda_local_var_23734_14_non_const_i]);
if (1)
{
(__cuda_local_var_23728_11_non_const_key.x) = (_Z9floatFlipILb1EEjj((__cuda_local_var_23728_11_non_const_key.x)));
(__cuda_local_var_23728_11_non_const_key.y) = (_Z9floatFlipILb1EEjj((__cuda_local_var_23728_11_non_const_key.y)));
(__cuda_local_var_23728_11_non_const_key.z) = (_Z9floatFlipILb1EEjj((__cuda_local_var_23728_11_non_const_key.z)));
(__cuda_local_var_23728_11_non_const_key.w) = (_Z9floatFlipILb1EEjj((__cuda_local_var_23728_11_non_const_key.w)));
}
}
__syncthreads();
_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4((&__cuda_local_var_23728_11_non_const_key));
if (0)
{
if (__cuda_local_var_23735_14_non_const_idx < numElements)
{
 uint *__cuda_local_var_23776_23_non_const_keys1;
__cuda_local_var_23776_23_non_const_keys1 = ((uint *)keysOut);
(__cuda_local_var_23776_23_non_const_keys1[__cuda_local_var_23735_14_non_const_idx]) = (__cuda_local_var_23728_11_non_const_key.x);
if ((__cuda_local_var_23735_14_non_const_idx + 1U) < numElements)
{
(__cuda_local_var_23776_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 1U)]) = (__cuda_local_var_23728_11_non_const_key.y);
if ((__cuda_local_var_23735_14_non_const_idx + 2U) < numElements)
{
(__cuda_local_var_23776_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 2U)]) = (__cuda_local_var_23728_11_non_const_key.z);
}
}
}
}
else
{
(keysOut[__cuda_local_var_23734_14_non_const_i]) = __cuda_local_var_23728_11_non_const_key;
}
if (0) {
__cuda_local_var_23730_10_non_const_blockId += (gridDim.x); } else {
goto __T219; }
} __T219:;
}}
__attribute__((global)) void _Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb1ELb1EEvP5uint4S1_jj(
uint4 *keysOut,
uint4 *keysIn,
uint numElements,
uint totalBlocks){
{
 uint4 __cuda_local_var_23728_11_non_const_key;
 uint __cuda_local_var_23730_10_non_const_blockId;
__cuda_local_var_23730_10_non_const_blockId = (blockIdx.x);
while ((0) || (__cuda_local_var_23730_10_non_const_blockId < totalBlocks))
{ uint4 __T220;
 uint __cuda_local_var_23734_14_non_const_i;
 uint __cuda_local_var_23735_14_non_const_idx;
__cuda_local_var_23734_14_non_const_i = ((__cuda_local_var_23730_10_non_const_blockId * (blockDim.x)) + (threadIdx.x));
__cuda_local_var_23735_14_non_const_idx = (__cuda_local_var_23734_14_non_const_i << 2);
if ((1) && ((__cuda_local_var_23735_14_non_const_idx + 3U) >= numElements))
{
if (__cuda_local_var_23735_14_non_const_idx >= numElements)
{
__cuda_local_var_23728_11_non_const_key = ((((((__T220.x) = 4294967295U) , (void)((__T220.y) = 4294967295U)) , (void)((__T220.z) = 4294967295U)) , (void)((__T220.w) = 4294967295U)) , __T220);
}
else
{
 uint *__cuda_local_var_23747_23_non_const_keys1;
__cuda_local_var_23747_23_non_const_keys1 = ((uint *)keysIn);
(__cuda_local_var_23728_11_non_const_key.x) = ((__cuda_local_var_23735_14_non_const_idx < numElements) ? (_Z9floatFlipILb1EEjj((__cuda_local_var_23747_23_non_const_keys1[__cuda_local_var_23735_14_non_const_idx]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.y) = (((__cuda_local_var_23735_14_non_const_idx + 1U) < numElements) ? (_Z9floatFlipILb1EEjj((__cuda_local_var_23747_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 1U)]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.z) = (((__cuda_local_var_23735_14_non_const_idx + 2U) < numElements) ? (_Z9floatFlipILb1EEjj((__cuda_local_var_23747_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 2U)]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.w) = 4294967295U;
}
}
else
{
__cuda_local_var_23728_11_non_const_key = (keysIn[__cuda_local_var_23734_14_non_const_i]);
if (1)
{
(__cuda_local_var_23728_11_non_const_key.x) = (_Z9floatFlipILb1EEjj((__cuda_local_var_23728_11_non_const_key.x)));
(__cuda_local_var_23728_11_non_const_key.y) = (_Z9floatFlipILb1EEjj((__cuda_local_var_23728_11_non_const_key.y)));
(__cuda_local_var_23728_11_non_const_key.z) = (_Z9floatFlipILb1EEjj((__cuda_local_var_23728_11_non_const_key.z)));
(__cuda_local_var_23728_11_non_const_key.w) = (_Z9floatFlipILb1EEjj((__cuda_local_var_23728_11_non_const_key.w)));
}
}
__syncthreads();
_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4((&__cuda_local_var_23728_11_non_const_key));
if ((1) && ((__cuda_local_var_23735_14_non_const_idx + 3U) >= numElements))
{
if (__cuda_local_var_23735_14_non_const_idx < numElements)
{
 uint *__cuda_local_var_23776_23_non_const_keys1;
__cuda_local_var_23776_23_non_const_keys1 = ((uint *)keysOut);
(__cuda_local_var_23776_23_non_const_keys1[__cuda_local_var_23735_14_non_const_idx]) = (__cuda_local_var_23728_11_non_const_key.x);
if ((__cuda_local_var_23735_14_non_const_idx + 1U) < numElements)
{
(__cuda_local_var_23776_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 1U)]) = (__cuda_local_var_23728_11_non_const_key.y);
if ((__cuda_local_var_23735_14_non_const_idx + 2U) < numElements)
{
(__cuda_local_var_23776_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 2U)]) = (__cuda_local_var_23728_11_non_const_key.z);
}
}
}
}
else
{
(keysOut[__cuda_local_var_23734_14_non_const_i]) = __cuda_local_var_23728_11_non_const_key;
}
if (1) {
__cuda_local_var_23730_10_non_const_blockId += (gridDim.x); } else {
goto __T221; }
} __T221:;
}}
__attribute__((global)) void _Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb1ELb0EEvP5uint4S1_jj(
uint4 *keysOut,
uint4 *keysIn,
uint numElements,
uint totalBlocks){
{
 uint4 __cuda_local_var_23728_11_non_const_key;
 uint __cuda_local_var_23730_10_non_const_blockId;
__cuda_local_var_23730_10_non_const_blockId = (blockIdx.x);
while (1)
{ uint4 __T222;
 uint __cuda_local_var_23734_14_non_const_i;
 uint __cuda_local_var_23735_14_non_const_idx;
__cuda_local_var_23734_14_non_const_i = ((__cuda_local_var_23730_10_non_const_blockId * (blockDim.x)) + (threadIdx.x));
__cuda_local_var_23735_14_non_const_idx = (__cuda_local_var_23734_14_non_const_i << 2);
if ((1) && ((__cuda_local_var_23735_14_non_const_idx + 3U) >= numElements))
{
if (__cuda_local_var_23735_14_non_const_idx >= numElements)
{
__cuda_local_var_23728_11_non_const_key = ((((((__T222.x) = 4294967295U) , (void)((__T222.y) = 4294967295U)) , (void)((__T222.z) = 4294967295U)) , (void)((__T222.w) = 4294967295U)) , __T222);
}
else
{
 uint *__cuda_local_var_23747_23_non_const_keys1;
__cuda_local_var_23747_23_non_const_keys1 = ((uint *)keysIn);
(__cuda_local_var_23728_11_non_const_key.x) = ((__cuda_local_var_23735_14_non_const_idx < numElements) ? (_Z9floatFlipILb1EEjj((__cuda_local_var_23747_23_non_const_keys1[__cuda_local_var_23735_14_non_const_idx]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.y) = (((__cuda_local_var_23735_14_non_const_idx + 1U) < numElements) ? (_Z9floatFlipILb1EEjj((__cuda_local_var_23747_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 1U)]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.z) = (((__cuda_local_var_23735_14_non_const_idx + 2U) < numElements) ? (_Z9floatFlipILb1EEjj((__cuda_local_var_23747_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 2U)]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.w) = 4294967295U;
}
}
else
{
__cuda_local_var_23728_11_non_const_key = (keysIn[__cuda_local_var_23734_14_non_const_i]);
if (1)
{
(__cuda_local_var_23728_11_non_const_key.x) = (_Z9floatFlipILb1EEjj((__cuda_local_var_23728_11_non_const_key.x)));
(__cuda_local_var_23728_11_non_const_key.y) = (_Z9floatFlipILb1EEjj((__cuda_local_var_23728_11_non_const_key.y)));
(__cuda_local_var_23728_11_non_const_key.z) = (_Z9floatFlipILb1EEjj((__cuda_local_var_23728_11_non_const_key.z)));
(__cuda_local_var_23728_11_non_const_key.w) = (_Z9floatFlipILb1EEjj((__cuda_local_var_23728_11_non_const_key.w)));
}
}
__syncthreads();
_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4((&__cuda_local_var_23728_11_non_const_key));
if ((1) && ((__cuda_local_var_23735_14_non_const_idx + 3U) >= numElements))
{
if (__cuda_local_var_23735_14_non_const_idx < numElements)
{
 uint *__cuda_local_var_23776_23_non_const_keys1;
__cuda_local_var_23776_23_non_const_keys1 = ((uint *)keysOut);
(__cuda_local_var_23776_23_non_const_keys1[__cuda_local_var_23735_14_non_const_idx]) = (__cuda_local_var_23728_11_non_const_key.x);
if ((__cuda_local_var_23735_14_non_const_idx + 1U) < numElements)
{
(__cuda_local_var_23776_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 1U)]) = (__cuda_local_var_23728_11_non_const_key.y);
if ((__cuda_local_var_23735_14_non_const_idx + 2U) < numElements)
{
(__cuda_local_var_23776_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 2U)]) = (__cuda_local_var_23728_11_non_const_key.z);
}
}
}
}
else
{
(keysOut[__cuda_local_var_23734_14_non_const_i]) = __cuda_local_var_23728_11_non_const_key;
}
if (0) {
__cuda_local_var_23730_10_non_const_blockId += (gridDim.x); } else {
goto __T223; }
} __T223:;
}}
__attribute__((global)) void _Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb0ELb1EEvP5uint4S1_jj(
uint4 *keysOut,
uint4 *keysIn,
uint numElements,
uint totalBlocks){
{
 uint4 __cuda_local_var_23728_11_non_const_key;
 uint __cuda_local_var_23730_10_non_const_blockId;
__cuda_local_var_23730_10_non_const_blockId = (blockIdx.x);
while ((0) || (__cuda_local_var_23730_10_non_const_blockId < totalBlocks))
{ uint4 __T224;
 uint __cuda_local_var_23734_14_non_const_i;
 uint __cuda_local_var_23735_14_non_const_idx;
__cuda_local_var_23734_14_non_const_i = ((__cuda_local_var_23730_10_non_const_blockId * (blockDim.x)) + (threadIdx.x));
__cuda_local_var_23735_14_non_const_idx = (__cuda_local_var_23734_14_non_const_i << 2);
if (0)
{
if (__cuda_local_var_23735_14_non_const_idx >= numElements)
{
__cuda_local_var_23728_11_non_const_key = ((((((__T224.x) = 4294967295U) , (void)((__T224.y) = 4294967295U)) , (void)((__T224.z) = 4294967295U)) , (void)((__T224.w) = 4294967295U)) , __T224);
}
else
{
 uint *__cuda_local_var_23747_23_non_const_keys1;
__cuda_local_var_23747_23_non_const_keys1 = ((uint *)keysIn);
(__cuda_local_var_23728_11_non_const_key.x) = ((__cuda_local_var_23735_14_non_const_idx < numElements) ? (_Z9floatFlipILb0EEjj((__cuda_local_var_23747_23_non_const_keys1[__cuda_local_var_23735_14_non_const_idx]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.y) = (((__cuda_local_var_23735_14_non_const_idx + 1U) < numElements) ? (_Z9floatFlipILb0EEjj((__cuda_local_var_23747_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 1U)]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.z) = (((__cuda_local_var_23735_14_non_const_idx + 2U) < numElements) ? (_Z9floatFlipILb0EEjj((__cuda_local_var_23747_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 2U)]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.w) = 4294967295U;
}
}
else
{
__cuda_local_var_23728_11_non_const_key = (keysIn[__cuda_local_var_23734_14_non_const_i]);
if (0)
{
(__cuda_local_var_23728_11_non_const_key.x) = (_Z9floatFlipILb0EEjj((__cuda_local_var_23728_11_non_const_key.x)));
(__cuda_local_var_23728_11_non_const_key.y) = (_Z9floatFlipILb0EEjj((__cuda_local_var_23728_11_non_const_key.y)));
(__cuda_local_var_23728_11_non_const_key.z) = (_Z9floatFlipILb0EEjj((__cuda_local_var_23728_11_non_const_key.z)));
(__cuda_local_var_23728_11_non_const_key.w) = (_Z9floatFlipILb0EEjj((__cuda_local_var_23728_11_non_const_key.w)));
}
}
__syncthreads();
_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4((&__cuda_local_var_23728_11_non_const_key));
if (0)
{
if (__cuda_local_var_23735_14_non_const_idx < numElements)
{
 uint *__cuda_local_var_23776_23_non_const_keys1;
__cuda_local_var_23776_23_non_const_keys1 = ((uint *)keysOut);
(__cuda_local_var_23776_23_non_const_keys1[__cuda_local_var_23735_14_non_const_idx]) = (__cuda_local_var_23728_11_non_const_key.x);
if ((__cuda_local_var_23735_14_non_const_idx + 1U) < numElements)
{
(__cuda_local_var_23776_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 1U)]) = (__cuda_local_var_23728_11_non_const_key.y);
if ((__cuda_local_var_23735_14_non_const_idx + 2U) < numElements)
{
(__cuda_local_var_23776_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 2U)]) = (__cuda_local_var_23728_11_non_const_key.z);
}
}
}
}
else
{
(keysOut[__cuda_local_var_23734_14_non_const_i]) = __cuda_local_var_23728_11_non_const_key;
}
if (1) {
__cuda_local_var_23730_10_non_const_blockId += (gridDim.x); } else {
goto __T225; }
} __T225:;
}}
__attribute__((global)) void _Z23radixSortBlocksKeysOnlyILj4ELj0ELb1ELb0ELb0EEvP5uint4S1_jj(
uint4 *keysOut,
uint4 *keysIn,
uint numElements,
uint totalBlocks){
{
 uint4 __cuda_local_var_23728_11_non_const_key;
 uint __cuda_local_var_23730_10_non_const_blockId;
__cuda_local_var_23730_10_non_const_blockId = (blockIdx.x);
while (1)
{ uint4 __T226;
 uint __cuda_local_var_23734_14_non_const_i;
 uint __cuda_local_var_23735_14_non_const_idx;
__cuda_local_var_23734_14_non_const_i = ((__cuda_local_var_23730_10_non_const_blockId * (blockDim.x)) + (threadIdx.x));
__cuda_local_var_23735_14_non_const_idx = (__cuda_local_var_23734_14_non_const_i << 2);
if (0)
{
if (__cuda_local_var_23735_14_non_const_idx >= numElements)
{
__cuda_local_var_23728_11_non_const_key = ((((((__T226.x) = 4294967295U) , (void)((__T226.y) = 4294967295U)) , (void)((__T226.z) = 4294967295U)) , (void)((__T226.w) = 4294967295U)) , __T226);
}
else
{
 uint *__cuda_local_var_23747_23_non_const_keys1;
__cuda_local_var_23747_23_non_const_keys1 = ((uint *)keysIn);
(__cuda_local_var_23728_11_non_const_key.x) = ((__cuda_local_var_23735_14_non_const_idx < numElements) ? (_Z9floatFlipILb0EEjj((__cuda_local_var_23747_23_non_const_keys1[__cuda_local_var_23735_14_non_const_idx]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.y) = (((__cuda_local_var_23735_14_non_const_idx + 1U) < numElements) ? (_Z9floatFlipILb0EEjj((__cuda_local_var_23747_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 1U)]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.z) = (((__cuda_local_var_23735_14_non_const_idx + 2U) < numElements) ? (_Z9floatFlipILb0EEjj((__cuda_local_var_23747_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 2U)]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.w) = 4294967295U;
}
}
else
{
__cuda_local_var_23728_11_non_const_key = (keysIn[__cuda_local_var_23734_14_non_const_i]);
if (0)
{
(__cuda_local_var_23728_11_non_const_key.x) = (_Z9floatFlipILb0EEjj((__cuda_local_var_23728_11_non_const_key.x)));
(__cuda_local_var_23728_11_non_const_key.y) = (_Z9floatFlipILb0EEjj((__cuda_local_var_23728_11_non_const_key.y)));
(__cuda_local_var_23728_11_non_const_key.z) = (_Z9floatFlipILb0EEjj((__cuda_local_var_23728_11_non_const_key.z)));
(__cuda_local_var_23728_11_non_const_key.w) = (_Z9floatFlipILb0EEjj((__cuda_local_var_23728_11_non_const_key.w)));
}
}
__syncthreads();
_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4((&__cuda_local_var_23728_11_non_const_key));
if (0)
{
if (__cuda_local_var_23735_14_non_const_idx < numElements)
{
 uint *__cuda_local_var_23776_23_non_const_keys1;
__cuda_local_var_23776_23_non_const_keys1 = ((uint *)keysOut);
(__cuda_local_var_23776_23_non_const_keys1[__cuda_local_var_23735_14_non_const_idx]) = (__cuda_local_var_23728_11_non_const_key.x);
if ((__cuda_local_var_23735_14_non_const_idx + 1U) < numElements)
{
(__cuda_local_var_23776_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 1U)]) = (__cuda_local_var_23728_11_non_const_key.y);
if ((__cuda_local_var_23735_14_non_const_idx + 2U) < numElements)
{
(__cuda_local_var_23776_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 2U)]) = (__cuda_local_var_23728_11_non_const_key.z);
}
}
}
}
else
{
(keysOut[__cuda_local_var_23734_14_non_const_i]) = __cuda_local_var_23728_11_non_const_key;
}
if (0) {
__cuda_local_var_23730_10_non_const_blockId += (gridDim.x); } else {
goto __T227; }
} __T227:;
}}
__attribute__((global)) void _Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb0ELb1EEvP5uint4S1_jj(
uint4 *keysOut,
uint4 *keysIn,
uint numElements,
uint totalBlocks){
{
 uint4 __cuda_local_var_23728_11_non_const_key;
 uint __cuda_local_var_23730_10_non_const_blockId;
__cuda_local_var_23730_10_non_const_blockId = (blockIdx.x);
while ((0) || (__cuda_local_var_23730_10_non_const_blockId < totalBlocks))
{ uint4 __T228;
 uint __cuda_local_var_23734_14_non_const_i;
 uint __cuda_local_var_23735_14_non_const_idx;
__cuda_local_var_23734_14_non_const_i = ((__cuda_local_var_23730_10_non_const_blockId * (blockDim.x)) + (threadIdx.x));
__cuda_local_var_23735_14_non_const_idx = (__cuda_local_var_23734_14_non_const_i << 2);
if ((1) && ((__cuda_local_var_23735_14_non_const_idx + 3U) >= numElements))
{
if (__cuda_local_var_23735_14_non_const_idx >= numElements)
{
__cuda_local_var_23728_11_non_const_key = ((((((__T228.x) = 4294967295U) , (void)((__T228.y) = 4294967295U)) , (void)((__T228.z) = 4294967295U)) , (void)((__T228.w) = 4294967295U)) , __T228);
}
else
{
 uint *__cuda_local_var_23747_23_non_const_keys1;
__cuda_local_var_23747_23_non_const_keys1 = ((uint *)keysIn);
(__cuda_local_var_23728_11_non_const_key.x) = ((__cuda_local_var_23735_14_non_const_idx < numElements) ? (_Z9floatFlipILb0EEjj((__cuda_local_var_23747_23_non_const_keys1[__cuda_local_var_23735_14_non_const_idx]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.y) = (((__cuda_local_var_23735_14_non_const_idx + 1U) < numElements) ? (_Z9floatFlipILb0EEjj((__cuda_local_var_23747_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 1U)]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.z) = (((__cuda_local_var_23735_14_non_const_idx + 2U) < numElements) ? (_Z9floatFlipILb0EEjj((__cuda_local_var_23747_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 2U)]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.w) = 4294967295U;
}
}
else
{
__cuda_local_var_23728_11_non_const_key = (keysIn[__cuda_local_var_23734_14_non_const_i]);
if (0)
{
(__cuda_local_var_23728_11_non_const_key.x) = (_Z9floatFlipILb0EEjj((__cuda_local_var_23728_11_non_const_key.x)));
(__cuda_local_var_23728_11_non_const_key.y) = (_Z9floatFlipILb0EEjj((__cuda_local_var_23728_11_non_const_key.y)));
(__cuda_local_var_23728_11_non_const_key.z) = (_Z9floatFlipILb0EEjj((__cuda_local_var_23728_11_non_const_key.z)));
(__cuda_local_var_23728_11_non_const_key.w) = (_Z9floatFlipILb0EEjj((__cuda_local_var_23728_11_non_const_key.w)));
}
}
__syncthreads();
_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4((&__cuda_local_var_23728_11_non_const_key));
if ((1) && ((__cuda_local_var_23735_14_non_const_idx + 3U) >= numElements))
{
if (__cuda_local_var_23735_14_non_const_idx < numElements)
{
 uint *__cuda_local_var_23776_23_non_const_keys1;
__cuda_local_var_23776_23_non_const_keys1 = ((uint *)keysOut);
(__cuda_local_var_23776_23_non_const_keys1[__cuda_local_var_23735_14_non_const_idx]) = (__cuda_local_var_23728_11_non_const_key.x);
if ((__cuda_local_var_23735_14_non_const_idx + 1U) < numElements)
{
(__cuda_local_var_23776_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 1U)]) = (__cuda_local_var_23728_11_non_const_key.y);
if ((__cuda_local_var_23735_14_non_const_idx + 2U) < numElements)
{
(__cuda_local_var_23776_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 2U)]) = (__cuda_local_var_23728_11_non_const_key.z);
}
}
}
}
else
{
(keysOut[__cuda_local_var_23734_14_non_const_i]) = __cuda_local_var_23728_11_non_const_key;
}
if (1) {
__cuda_local_var_23730_10_non_const_blockId += (gridDim.x); } else {
goto __T229; }
} __T229:;
}}
__attribute__((global)) void _Z23radixSortBlocksKeysOnlyILj4ELj0ELb0ELb0ELb0EEvP5uint4S1_jj(
uint4 *keysOut,
uint4 *keysIn,
uint numElements,
uint totalBlocks){
{
 uint4 __cuda_local_var_23728_11_non_const_key;
 uint __cuda_local_var_23730_10_non_const_blockId;
__cuda_local_var_23730_10_non_const_blockId = (blockIdx.x);
while (1)
{ uint4 __T230;
 uint __cuda_local_var_23734_14_non_const_i;
 uint __cuda_local_var_23735_14_non_const_idx;
__cuda_local_var_23734_14_non_const_i = ((__cuda_local_var_23730_10_non_const_blockId * (blockDim.x)) + (threadIdx.x));
__cuda_local_var_23735_14_non_const_idx = (__cuda_local_var_23734_14_non_const_i << 2);
if ((1) && ((__cuda_local_var_23735_14_non_const_idx + 3U) >= numElements))
{
if (__cuda_local_var_23735_14_non_const_idx >= numElements)
{
__cuda_local_var_23728_11_non_const_key = ((((((__T230.x) = 4294967295U) , (void)((__T230.y) = 4294967295U)) , (void)((__T230.z) = 4294967295U)) , (void)((__T230.w) = 4294967295U)) , __T230);
}
else
{
 uint *__cuda_local_var_23747_23_non_const_keys1;
__cuda_local_var_23747_23_non_const_keys1 = ((uint *)keysIn);
(__cuda_local_var_23728_11_non_const_key.x) = ((__cuda_local_var_23735_14_non_const_idx < numElements) ? (_Z9floatFlipILb0EEjj((__cuda_local_var_23747_23_non_const_keys1[__cuda_local_var_23735_14_non_const_idx]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.y) = (((__cuda_local_var_23735_14_non_const_idx + 1U) < numElements) ? (_Z9floatFlipILb0EEjj((__cuda_local_var_23747_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 1U)]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.z) = (((__cuda_local_var_23735_14_non_const_idx + 2U) < numElements) ? (_Z9floatFlipILb0EEjj((__cuda_local_var_23747_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 2U)]))) : 4294967295U);
(__cuda_local_var_23728_11_non_const_key.w) = 4294967295U;
}
}
else
{
__cuda_local_var_23728_11_non_const_key = (keysIn[__cuda_local_var_23734_14_non_const_i]);
if (0)
{
(__cuda_local_var_23728_11_non_const_key.x) = (_Z9floatFlipILb0EEjj((__cuda_local_var_23728_11_non_const_key.x)));
(__cuda_local_var_23728_11_non_const_key.y) = (_Z9floatFlipILb0EEjj((__cuda_local_var_23728_11_non_const_key.y)));
(__cuda_local_var_23728_11_non_const_key.z) = (_Z9floatFlipILb0EEjj((__cuda_local_var_23728_11_non_const_key.z)));
(__cuda_local_var_23728_11_non_const_key.w) = (_Z9floatFlipILb0EEjj((__cuda_local_var_23728_11_non_const_key.w)));
}
}
__syncthreads();
_Z22radixSortBlockKeysOnlyILj4ELj0EEvR5uint4((&__cuda_local_var_23728_11_non_const_key));
if ((1) && ((__cuda_local_var_23735_14_non_const_idx + 3U) >= numElements))
{
if (__cuda_local_var_23735_14_non_const_idx < numElements)
{
 uint *__cuda_local_var_23776_23_non_const_keys1;
__cuda_local_var_23776_23_non_const_keys1 = ((uint *)keysOut);
(__cuda_local_var_23776_23_non_const_keys1[__cuda_local_var_23735_14_non_const_idx]) = (__cuda_local_var_23728_11_non_const_key.x);
if ((__cuda_local_var_23735_14_non_const_idx + 1U) < numElements)
{
(__cuda_local_var_23776_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 1U)]) = (__cuda_local_var_23728_11_non_const_key.y);
if ((__cuda_local_var_23735_14_non_const_idx + 2U) < numElements)
{
(__cuda_local_var_23776_23_non_const_keys1[(__cuda_local_var_23735_14_non_const_idx + 2U)]) = (__cuda_local_var_23728_11_non_const_key.z);
}
}
}
}
else
{
(keysOut[__cuda_local_var_23734_14_non_const_i]) = __cuda_local_var_23728_11_non_const_key;
}
if (0) {
__cuda_local_var_23730_10_non_const_blockId += (gridDim.x); } else {
goto __T231; }
} __T231:;
}}
