
template<bool doFlip>
__global__ void floatFlip(int *index) {
  __shared__ int a[4];
  if (doFlip) {
    *(index + threadIdx.x) += blockDim.x;
    *(a+threadIdx.x) = *(index+threadIdx.x);
  } else  {
    *(index + threadIdx.x) -= blockDim.x;
    *(a+threadIdx.x) = *(index+threadIdx.x);
  }
}

int main(void) {
  int hIdx[4] = {1,2,3,4};
  int *dIdx;   
  cudaMalloc((void**)&dIdx, sizeof(int)*4);
  cudaMemcpy(dIdx, hIdx, sizeof(int)*4, cudaMemcpyHostToDevice);

  //__modify_Block(4);
  //__begin_GPU();
  floatFlip<true><<<1,4>>>(dIdx);
  //__end_GPU();

  cudaFree(dIdx);
}
