//Tyler Sorensen
//tylersorensen3221@hotmail.com
//University of Utah

//GKLEE version of gpu.cu
//Note that GKLEE reports no races with default warp-based scheduling
#include "klee.h"
#include "cutil.h"
#include "stdio.h"

#define SIZE 64


__global__ void kernel(int* x, int* y)
{
  int index = threadIdx.x;
  y[index] = x[index] + y[index];
  
  if (index != 63)
    y[index+1] = 1111;       
}

int main( void ) {
  int *vector_hx, *vector_dx;
  int *vector_hy, *vector_dy;
  
  //Allocating Memory on the host and device
  cudaMalloc( (void**)&vector_dx, sizeof(int)*SIZE);
  cudaMalloc( (void**)&vector_dy, sizeof(int)*SIZE);

  vector_hx = new int[SIZE];
  vector_hy = new int[SIZE];
  
  //Init vectors with:
  //x[i] = y[i] = i
  for (int i = 0; i < SIZE; i++)
    {
      vector_hx[i] = vector_hy[i] = i;      	    
    }

  //Copy memory over to device
  cudaMemcpy(vector_dx, vector_hx, sizeof(int)*SIZE, cudaMemcpyHostToDevice);
  cudaMemcpy(vector_dy, vector_hy, sizeof(int)*SIZE, cudaMemcpyHostToDevice);

  //Call the kernel
  __modify_Block(64);
  __modify_Grid(1);
  __begin_GPU();
  kernel(vector_dx, vector_dy);
  __end_GPU();

  cudaMemcpy(vector_hy, vector_dy, sizeof(int)*SIZE, cudaMemcpyDeviceToHost);

  //Don't print in GKLEE version
  //  for (int i = 0; i < SIZE; i++)
  //  printf("%i\n");

  //cleanup
  delete vector_hx;
  delete vector_hy;

  cudaFree(vector_dx);
  cudaFree(vector_dy);

  return 0;
}
