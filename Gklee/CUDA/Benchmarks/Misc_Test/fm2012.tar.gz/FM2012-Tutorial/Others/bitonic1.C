#include "cutil.h"
#include "klee.h"
#include "stdio.h"
#include <cstdlib>

#ifndef NUM
#define  NUM  4
#endif

#ifdef REPLAY

#include "bitonic.cc"

#else

__shared__ int shared[NUM];

__device__ inline void swap(int & a, int & b) {
  // Alternative swap doesn't use a temporary register:
  // a ^= b;
  // b ^= a;
  // a ^= b;
  
  int tmp = a;
  a = b;
  b = tmp;
}

__global__ void BitonicKernel(int * values)
{
  unsigned int tid = threadIdx.x;

  // Copy input to shared mem.  
  shared[tid] = values[tid];
  __syncthreads();

  // Parallel bitonic sort.
  for (unsigned int k = 2; k <= blockDim.x; k *= 2) {
    for (unsigned int j = k / 2; j>0; j /= 2) {
      unsigned int ixj = tid ^ j;
      
      if (ixj > tid) {
	if ((tid & k) == 0) {
	  if (shared[tid] > shared[ixj])
	    swap(shared[tid], shared[ixj]);
	}
	else {
	  if (shared[tid] < shared[ixj])
	    swap(shared[tid], shared[ixj]);
	}
      }
      __syncthreads();
    }
  } //end sort
  
  // Write result.
  values[tid] = shared[tid];
}

#endif

// *************************************************************
//  Driver 
// *************************************************************

#ifdef RAND

int main() {
  __input__ int values[NUM];

  for (int k = 0; k < 5; k++) {
    printf("input: ");
    for (int i = 0; i < NUM; i++) {
      values[i] = rand();
      printf("%d ", values[i]);
    }
    printf("\n");
    
    // __set_PR('l', 4, true);
    // __set_PR('B', 1, false);
    // the following is equivalent to calling the kernel using <<<...>>>(BitonicKernel)
    __begin_GPU(NUM);
    BitonicKernel(values);
    __end_GPU();
  }

  // // post-conditions
  // for (int i = 1; i < NUM; i++) {
  //   if (values[i] < values[i-1]) {
  //     printf("The sorting algorithm is incorrect since values[%d] < values[%d]!\n", i, i-1);
  //   }
  // }
  return 0;
}

#else

int main() {
  __input__ int values[NUM];
  klee_make_symbolic(values, sizeof(values), "input");
  
  // // concretization
  // for (int i = 0; i < NUM; i++) {
  //   if (i % 4 != 0) {
  //     values[i] = i;
  //   } 
  // } 
  
#ifndef REPLAY

  // __set_PR('l', 4, true);
  // __set_PR('B', 1, false);
  // the following is equivalent to calling the kernel using <<<...>>>(BitonicKernel)
  __begin_GPU(NUM);
  BitonicKernel(values);
  __end_GPU();

#else
  
  BitonicKernelReplay(values);
  
#endif
  
  // post-conditions
  for (int i = 1; i < NUM; i++) {
    if (values[i] < values[i-1]) {
      printf("The sorting algorithm is incorrect since values[%d] < values[%d]!\n", i, i-1);
    }
  }
  return 0;
}

#endif
