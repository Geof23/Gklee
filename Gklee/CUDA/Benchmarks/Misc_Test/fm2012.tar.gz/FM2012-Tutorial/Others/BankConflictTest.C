
#include <klee.h>
#include <stdio.h>
#include "cutil.h"

#define NUM 4

__shared__ int v[NUM];

__kernel__ void bankConflict() {
  int temp;
  v[ (threadIdx.x == 0 || threadIdx.x == 1) ? 0 : threadIdx.x ] = 2;
}

int main() {

  __begin_GPU(NUM);
  bankConflict();
  __end_GPU();

  return 0;
}
