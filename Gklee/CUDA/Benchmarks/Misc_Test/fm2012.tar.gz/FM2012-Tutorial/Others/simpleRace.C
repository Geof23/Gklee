#include "cutil.h"
#include "klee.h"
#include "stdio.h"

#define NUM 4

__shared__ int shared[NUM];

__global__ void simpleSummation(int * values)
{
  unsigned int tid = threadIdx.x;

  // Copy input to shared mem.  
  shared[tid] = values[tid];
  //__syncthreads();

  // Compute
  if(tid > 0) shared[tid] = shared[tid-1];

  // __syncthreads();  
  // Write result.
  values[tid] = shared[tid];
}


// *************************************************************
//  Driver 
// *************************************************************

int main() {
  __input__ int values[NUM];
  klee_make_symbolic(values, sizeof(values), "input");

  klee_assume(values[0] == values[1]);
  klee_assume(values[1] == values[2]);
  klee_assume(values[2] == values[3]);
  
  __begin_GPU(NUM);
  simpleSummation(values);
  __end_GPU();

  // post-conditions
  for (int i = 1; i < NUM; i++) {
    if (values[i] == (values[i-1]+1)) {
      printf("The summation routine is behaving incorrectly at location %d\n", i);
    }
  }
  return 0;
}


