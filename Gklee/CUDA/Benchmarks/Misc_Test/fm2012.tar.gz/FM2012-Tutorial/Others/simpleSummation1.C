#include "cutil.h"
#include "klee.h"
#include "stdio.h"

#define NUM 33

__shared__ int shared[NUM];

__global__ void simpleSummation(int * values)
{
  unsigned int tid = threadIdx.x;

  // Copy input to shared mem.  
  shared[tid] = values[tid];
  //__syncthreads();

  // Compute
  shared[tid] += tid;

  // __syncthreads();  
  // Write result.
  values[tid] = shared[tid];
}


// *************************************************************
//  Driver 
// *************************************************************

int main() {
  __input__ int values[NUM];

  for (int i = 0; i < NUM; i++) {
    values[i] = 0;
  }
  
  __begin_GPU(NUM);
  simpleSummation(values);
  __end_GPU();

  // post-conditions
  for (int i = 1; i < NUM; i++) {
    if (values[i] != (values[i-1]+1)) {
      printf("The summation routine is behaving incorrectly at location %d\n", i);
    }
  }
  return 0;
}


